package com.user.entity;

import lombok.Data;

@Data
public class User {
    private Long id;
    private String name;
    private String document;
    private String celPhone;
    private String mail;
    private String amount;
    private String sale;
}