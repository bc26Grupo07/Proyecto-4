package com.user.events;

import com.user.entity.User;

public class UserCreatedEvent extends Event<User>{
}
