package com.user.events;

public enum EventType {
	CREATED, UPDATED, DELETED
}
