package pe.com.project.bank.model;

public enum EventType {
    CREATED, UPDATED, DELETED
}
